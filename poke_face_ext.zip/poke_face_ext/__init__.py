bl_info = {
    "name": "Poke Face Ext",
    "author": "NoirNeo",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Edit > Face",
    "description": "Poke face by the selected vertex",
    "warning": "",
    "doc_url": "",
    "category": "3D View",
}

translation_dict = {
    "en_US": {
        ("*", "Poke Face By Last Selected Vertex"): "Poke Face By Last Selected Vertex",
    },
    "ja_JP": {
        ("*", "Poke Face By Last Selected Vertex"): "選択した頂点を起点に扇状に分離",
    }
}

if "bpy" in locals():
    import imp
    imp.reload(create_edge)
else:
    from . import create_edge

import bpy

class Custom_OT_Operator(bpy.types.Operator):
    bl_idname = "mesh.custom_operator"
    bl_label = "選択した頂点を起点に扇状に分離" if bpy.app.translations.locale == "ja_JP" else "Poke Face By Last Selected Vertex"

    def execute(self, context):
        create_edge.devide_rectangle()
        return {'FINISHED'}

def custom_menu_func(self, context):
    self.layout.operator("mesh.custom_operator")

def menu_func(self, context):
    self.layout.separtor()
    self.layout.menu("VIEW3D_MT_edit_mesh_faces")

def register():
    bpy.utils.register_class(Custom_OT_Operator)
    bpy.types.VIEW3D_MT_edit_mesh_faces.append(custom_menu_func)
    bpy.types.VIEW3D_MT_edit_mesh.append(menu_func)

def unregister():
    bpy.utils.unregister_class(Custom_OT_Operator)
    bpy.types.VIEW3D_MT_edit_mesh_faces.remove(custom_menu_func)
    bpy.types.VIEW3D_MT_edit_mesh.remove(menu_func)

if __name__ == "__main__":
    register()