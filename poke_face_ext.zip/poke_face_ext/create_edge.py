import bpy
import bmesh

def devide_rectangle():
    print("devide_rectangle\n")
    obj = trans_edit()
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)

    selected_vertex = [vertex for vertex in bm.verts if vertex.select]

    last_selected_vertex = search_last_selected_vertex(bm)

    if not(selected_vertex):
        print('None Vertex Selected')
        return
    if not(last_selected_vertex):
        print('None Especial Vertex Selected')
        return

    exist_edges = [edge for edge in bm.edges if edge.verts[0] == last_selected_vertex or edge.verts[1] == last_selected_vertex]
    unable_vertex = []

    for edge in exist_edges:
        if(edge.verts[0] == last_selected_vertex):
            unable_vertex.append(edge.verts[1])
        else:
            unable_vertex.append(edge.verts[0])

    for vertex in selected_vertex:
        if (vertex not in unable_vertex) and (vertex != last_selected_vertex):
            bm.edges.new([vertex, last_selected_vertex])

    bmesh.update_edit_mesh(mesh)

def trans_edit():
    print("trans_edit\n")
    obj = bpy.context.active_object
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode = 'EDIT')

    return obj

def search_last_selected_vertex(bm: bmesh.types.BMVert):
    print("search_last_selected_vertex\n")
    selected_vertex = []
    for e in bm.select_history:
        if isinstance(e, bmesh.types.BMVert) and e.select:
            selected_vertex.append(e)

    if(selected_vertex):
        last_selected_vertex = selected_vertex[-1]
        selected_vertex = [vertex for vertex in bm.verts if vertex.select]
        return last_selected_vertex
    else:
        print('None Vertex Selected')
        return -1