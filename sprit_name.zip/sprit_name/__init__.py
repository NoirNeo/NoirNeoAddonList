bl_info = {
    "name": "All Sprit Translation",
    "author": "NoirNeo",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Edit > Face",
    "description": "Poke face by the selected vertex",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

translation_dict = {
    "en_US": {
        ("*", "Rename and Resize all strip"): "Rename and Resize all strip",
        ("*", "strip_name"): "strip_name",
        ("*", "strip_len"): "strip_len",
        ("*", "Apply"): "Apply",
    },
    "ja_JP": {
        ("*", "Rename and Resize all strip"): "すべてスプライトの名前と長さを変更する",
        ("*", "strip_name"): "名前",
        ("*", "strip_len"): "長さ",
        ("*", "Apply"): "適用",
    }
}

import bpy
from bpy.props import IntProperty, StringProperty
import time

class Sprit_OT_Translate(bpy.types.Operator):
    bl_idname = "nla.sprit_translate_func"
    bl_label = "NLA Sprit Translate Func"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return {'FINISHED'}

class NLA_OT_example_operator(bpy.types.Operator):
    bl_idname = "nla.sprit_translate_operator"
    bl_label = "すべてスプライトの名前と長さを変更する" if bpy.app.translations.locale == "ja_JP" else "Rename and Resize all strip"
    bl_description = "An example operator with a StringProperty"
    bl_options = {'REGISTER', 'UNDO'}

    initialized = False

    strip_name: StringProperty(
        name = "name",
        description = "rename all strip",
        default = "input text",
    )

    strip_len: IntProperty(
        name="length",
        description= "set strip length",
        default=100,
    )
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "strip_name", text = "strip_name")
        layout.prop(self, "strip_len", text = "strip_len")
        layout.operator("nla.sprit_translate_func", text = "Apply")
    
    def execute(self, context):
        if not self.initialized:
            self.strip_name = "input text"
            self.strip_len = get_max_len(self, context)
            self.initialized =True
        set_property(self, context)
        return {'FINISHED'}

def menu_fn(self, context):
    self.layout.separator()
    self.layout.operator(NLA_OT_example_operator.bl_idname)

def register():
    bpy.utils.register_class(Sprit_OT_Translate)
    bpy.utils.register_class(NLA_OT_example_operator)
    bpy.app.translations.register(__name__, translation_dict)
    bpy.types.NLA_MT_context_menu.append(menu_fn)

def unregister():
    bpy.utils.unregister_class(Sprit_OT_Translate)
    bpy.utils.unregister_class(NLA_OT_example_operator)
    bpy.app.translations.unregister(__name__)
    bpy.types.NLA_MT_context_menu.remove(menu_fn)
                    

def set_property(self, context):
    for obj in bpy.data.objects:
        if obj.animation_data:
            for track in obj.animation_data.nla_tracks:
                for strip in track.strips:
                    if strip.select:
                        strip.name = self.strip_name
                        strip.action_frame_start = 0
                        strip.action_frame_end = self.strip_len
    

def get_max_len(self, context):
    max_len = 100
    for obj in bpy.data.objects:
        if obj.animation_data:
            for track in obj.animation_data.nla_tracks:
                for strip in track.strips:
                    if strip.select:
                        if strip.action_frame_end > max_len:
                            max_len = strip.action_frame_end
    return int(max_len)

if __name__ == "__main__":
    register()