bl_info = {
    "name": "Convert to Strip",
    "author": "NoirNeo",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "Nonlinear Animation > Edit",
    "description": "Convert to Strip",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}

translation_dict = {
    "en_US": {
        ("*", "target_text"): "translated_text",
    },
    "ja_JP": {
        ("*", "target_text"): "翻訳語の文字列",
    }
}

import bpy

class ConvertStrip_OT_Operator(bpy.types.Operator):
    bl_idname = "nls.convert_strip"
    bl_label = "すべてストリップ化" if bpy.app.translations.locale == "ja_JP" else "Convert Strip All"
    bl_description = "convert strip all"
    bl_options = {"REGISTER", "UNDO"}

    initialize = False

    def execute(self, context):
        for obj in context.scene.objects:
            if obj.animation_data is not None:
                action = obj.animation_data.action
                if action is not None:
                    track = obj.animation_data.nla_tracks.new()
                    track.strips.new(action.name, int(action.frame_range[0]), action)
                    obj.animation_data.action = None
        if not self.initialize:
            self.initialize = True
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.separator()
    self.layout.operator(ConvertStrip_OT_Operator.bl_idname)

def register():
    bpy.utils.register_class(ConvertStrip_OT_Operator)
    bpy.types.NLA_MT_edit.append(menu_func)

def unregister():
    bpy.utils.unregister_class(ConvertStrip_OT_Operator)
    bpy.types.NLA_MT_edit.remove(menu_func)
if __name__ == "__main__":
    register()